package java_generics_MiloWideman;

/*
* a regular class �MyRegularClass�
*/
public class MyRegularClass {

   /*
   * generic method called �getSum� that takes 2 inputs of �T inp1�, �T inp2�
   */
   public static <T> T getSum(T inp1, T inp2) {
       return inp1;
   }

}
