package java_generics_MiloWideman;

public class MainEntry {
	   public static void main(String[] args) {

	       // local variable:mgi1 of type MyGenInterface that takes Integer and String as K,V

	       MyGenInterface<Integer, String> mgi1;

	       // local variable:mgi2 of type MyGenInterface that takes Integer and Integer as K,V
	       MyGenInterface<Integer, Integer> mgi2;

	       //Initialize mgi1 to instance of MyGenClass with inputs (1, �yourName�)
	       mgi1 = new MyGenClass<>(1, "Milo");
	       ////Initialize mgi2 to instance of MyGenClass with inputs (1, 2017)
	       mgi2 = new MyGenClass<>(1, 2017);

	       //Integer i1 set to returned value from MyRegularClass� getSum method passing (10,20)
	       Integer i1 = MyRegularClass.getSum(10, 20);
	       //Float f1 set to returned value from MyRegularClass� getSum method passing (100f,200f)
	       Float f1 = MyRegularClass.getSum(100f, 200f);

	       System.out.println("mgi1 Key: " + mgi1.getKey() + ", Value: " + mgi1.getValue());
	       System.out.println("mgi2 Key: " + mgi2.getKey() + ", Value: " + mgi2.getValue());

	       System.out.println("i1: " + i1);
	       System.out.println("f1: " + f1);

	   }

	}