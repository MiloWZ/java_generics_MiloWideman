package java_generics_MiloWideman;




public class MyGenClass<K, V> implements MyGenInterface<K, V> {

	   private K key;
	   private V value;

	   /**
	   * a constructor that takes �K _key�, �V _value� inputs and initializes �key�,
	   * �value� attributes
	   *
	   * @param key
	   * @param value
	   */
	   public MyGenClass(K _key, V _value) {
	       key = _key;
	       value = _value;
	   }

	   /**
	   * @return K returns key K
	   */
	   @Override
	   public K getKey() {
	       return key;
	   }

	   /**
	   * @return V return value V
	   */
	   @Override
	   public V getValue() {
	       return value;
	   }

	}