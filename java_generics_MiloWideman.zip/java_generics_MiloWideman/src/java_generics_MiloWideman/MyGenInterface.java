package java_generics_MiloWideman;



	public interface MyGenInterface<K,V>{

		
		public K getKey();
		public V getValue();

	}
